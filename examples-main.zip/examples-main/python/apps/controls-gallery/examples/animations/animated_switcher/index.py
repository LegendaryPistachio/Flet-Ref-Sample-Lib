name = "AnimatedSwitcher"

description = """A control that by default does a cross-fade between a new control and the control previously set on the AnimatedSwitcher as a `content`."""
