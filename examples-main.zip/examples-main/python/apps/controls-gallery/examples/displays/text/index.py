name = "Text"
description = """Text is a control for displaying text."""
