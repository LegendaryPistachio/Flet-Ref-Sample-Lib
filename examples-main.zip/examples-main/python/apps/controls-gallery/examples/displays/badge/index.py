name = "Badge"
description = """Badges are used to show notifications, counts, or status information about its child icon."""
