name = "PieChart"
description = """Draws a pie chart."""