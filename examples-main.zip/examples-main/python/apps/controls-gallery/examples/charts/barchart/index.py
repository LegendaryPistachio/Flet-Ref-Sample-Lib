name = "BarChart"
description = """Draws a bar chart."""