name = "LineChart"
description = """Draws a line chart."""