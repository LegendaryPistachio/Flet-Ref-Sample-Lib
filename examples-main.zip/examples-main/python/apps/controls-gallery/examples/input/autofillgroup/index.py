name = "AutofillGroup"
description = (
    """Groups autofillable controls such as TextField or CupertinoTextField."""
)
