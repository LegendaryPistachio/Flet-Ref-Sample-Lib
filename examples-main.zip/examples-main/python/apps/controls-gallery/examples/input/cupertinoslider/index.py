name = "CupertinoSlider"
description = """An macOS style slider."""
