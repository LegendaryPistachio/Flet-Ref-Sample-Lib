name = "RangeSlider"
description = (
    """A Material Design range slider. Used to select a range from a range of values."""
)
