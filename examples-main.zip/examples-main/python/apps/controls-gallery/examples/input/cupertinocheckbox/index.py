name = "CupertinoCheckbox"
description = """A macOS style checkbox."""
