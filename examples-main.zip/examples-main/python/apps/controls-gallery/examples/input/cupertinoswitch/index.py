name = "CupertinoSwitch"
description = """An iOS-style switch."""
