name = "CupertinoSlidingSegmentedButton"
description = """An iOS-13 style segmented control."""
