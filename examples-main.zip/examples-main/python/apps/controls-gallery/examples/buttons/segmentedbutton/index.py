name = "SegmentedButton"
description = """A Material button that allows the user to select from limited set of options and are typically used in cases where there are only 2-5 options."""
