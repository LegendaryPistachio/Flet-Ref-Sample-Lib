name = "NavigationDrawer"
description = """Material Design Navigation Drawer component."""