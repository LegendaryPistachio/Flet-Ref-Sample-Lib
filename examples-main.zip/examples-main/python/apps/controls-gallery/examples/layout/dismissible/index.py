name = "Dismissible"
description = """A control that can be dismissed by dragging in the indicated dismiss_direction. When dragged or flung in the specified dismiss_direction, it's content smoothly slides out of view."""
