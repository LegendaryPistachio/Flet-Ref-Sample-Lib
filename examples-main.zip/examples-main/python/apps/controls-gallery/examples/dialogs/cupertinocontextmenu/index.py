name = "CupertinoContextMenu"
description = (
    """A full-screen modal route that opens when it's content is long-pressed."""
)
