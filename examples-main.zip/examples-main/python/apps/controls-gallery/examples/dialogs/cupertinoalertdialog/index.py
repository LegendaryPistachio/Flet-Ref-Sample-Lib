name = "CupertinoAlertDialog"
description = """An iOS-style alert dialog."""
