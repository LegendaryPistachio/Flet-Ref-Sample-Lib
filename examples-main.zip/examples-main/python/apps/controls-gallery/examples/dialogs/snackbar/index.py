name = "SnackBar"
description = """A lightweight message with an optional action which briefly displays at the bottom of the screen."""
