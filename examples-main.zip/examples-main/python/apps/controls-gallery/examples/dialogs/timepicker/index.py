name = "TimePicker"
description = """A Material-style time picker dialog."""
