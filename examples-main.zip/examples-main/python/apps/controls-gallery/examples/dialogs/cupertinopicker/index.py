name = "CupertinoPicker"
description = """An iOS-styled picker."""
