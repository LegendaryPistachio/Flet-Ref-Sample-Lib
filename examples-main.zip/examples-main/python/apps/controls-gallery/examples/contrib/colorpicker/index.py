name = "ColorPicker"
description = """ColorPicker control is used for picking a color from color map in hex (rgb) format."""