# Flet `Video` control

`Video` control to use in Flet apps.