library flet_video;

export "src/create_control.dart" show createControl, ensureInitialized;
