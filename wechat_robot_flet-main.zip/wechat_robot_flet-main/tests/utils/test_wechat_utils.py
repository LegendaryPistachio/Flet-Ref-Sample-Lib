from ...wechat_robot.utils.wechat_utils import start_wechat

start_wechat()