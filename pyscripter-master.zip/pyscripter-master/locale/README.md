PyScripter translation is handled via transifex.com. You find our translation project at https://www.transifex.com/pyscripter/pyscripter/
If you want to help with a translation, please register at transifex.com and request to join one of our existing language teams.
You can then either translate via the transifex web interface or you can download the translation file locally and work on it with a tool like:
* [Virtaal](http://virtaal.translatehouse.org/download.html) or
* [poEdit](https://poedit.net/download)

We will keep the translations from transifex.com in sync with our github repository.

If you want to add a new language, feel free to request one via the transifex web interface, but please be aware that we are not interested in supporting many different variations of the same language. So **_de_** is ok, but we are not going to be happy with **_de_DE_**, **_de_CH_**, **_de_AT_** and so on.
