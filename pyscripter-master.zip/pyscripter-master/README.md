PyScripter is a free and open-source  Python Integrated Development
Environment (IDE) created with the ambition to become competitive in
functionality with commercial Windows-based IDEs available for other
languages.

* [![Download PyScripter](https://img.shields.io/sourceforge/dt/pyscripter.svg)](https://sourceforge.net/projects/pyscripter/files/)
* [Features](https://github.com/pyscripter/pyscripter/wiki/Features)
* [LLM-assisted coding](https://github.com/pyscripter/pyscripter/wiki/LLM_Support)
* [Screenshots](https://github.com/pyscripter/pyscripter/wiki/Screenshots)
* [Blog](https://pyscripter.blogspot.com/)
* [Support](https://groups.google.com/forum/#!forum/pyscripter)
* [Licence: MIT](https://github.com/pyscripter/pyscripter/blob/master/LICENSE)
* [![paypal](https://img.shields.io/badge/Donate-PayPal-brightgreen.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SX9B6G2GF5K4U)

![Screenshot](https://raw.githubusercontent.com/wiki/pyscripter/pyscripter/images/PyScripter_main_window.png)

