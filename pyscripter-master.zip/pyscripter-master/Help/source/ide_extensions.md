:::{index} IDE Extensions
:::

# Extending the IDE

:::{toctree}
externaltools
parameters
:::
