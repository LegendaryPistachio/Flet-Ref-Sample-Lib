.. pyscripter documentation master file, created by
   sphinx-quickstart on Mon Jun 17 13:31:24 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PyScripter's documentation
==========================

.. toctree::
   :titlesonly:
   :caption: Contents:
   :includehidden:

   intro
   mainidewindow
   main_menu
   ide_windows
   debug_windows
   editor
   llmintegration
   running_python
   programmer_utilities
   customization
   ide_extensions

Indices and tables
==================

* :ref:`genindex`
