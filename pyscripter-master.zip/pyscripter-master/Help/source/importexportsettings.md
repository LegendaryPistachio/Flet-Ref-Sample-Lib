:::{index} Customization; Import/Export Settings
:::

# Import/Export Settings

Using the commands under Tools, Options, Import Export, you can import and export 
shortcuts and syntax highlighting settings. This allows PyScripter users to share shortcuts 
and syntax highlighting settings. If you have customized these settings to match those of 
popular IDEs and editors such as Visual Studio and IDLE, you are encouraged to submit 
them to [pyscripter@google.com](mailto:pyscripter@google.com ), so 
that they will be made available to all users in a future version of PyScripter.
