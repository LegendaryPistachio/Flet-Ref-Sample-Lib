:::{index} Feedback
:::
:::{index} Support
:::
:::{index} IssueTracker
:::
:::{index} Updates
:::

# Support and Updates


Please submit bug reports and enhancement requests using the Issue Tracker at the  Github 
[PyScripter project page](https://github.com/pyscripter/pyscripter). A discussion and support forum is available at 
[http://groups.google.com/group/pyscripter](http://groups.google.com/group/pyscripter).

 Updates are availabe through Souceforge ([PyScripter downloads](https://sourceforge.net/projects/pyscripter/files)).  

You may  also get support and help by emailing [pyscripter@gmail.com](mailto://pyscripter@gmail.com).



