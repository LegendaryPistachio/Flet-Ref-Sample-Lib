:::{index} Customization; Toolbars
:::

# Toolbar Customization

PyScripter allows you to customize the toolbars by dragging and dropping command buttons on 
the toolbars, as you do in Microsoft Office for example. You can invoke the customization dialog 
shown below either through the [View menu](viewmenu) (Toolbars submenu), 
or from the context menu of the toolbars background.  
  
![graphic](images/toolbarcustomization1.JPG){align=center width="22.38em" height="22.31em"}
