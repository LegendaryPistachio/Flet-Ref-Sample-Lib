:::{index} Customization; Styles
:::

# Customizable Styles
  
In version 3.0, PyScripter introduced an updated style (skin) engine that allows the loading 
of external themes. Style information is stored in files with the "vsf" 
extension. Available style files are located in the directory %APPDATA%\PyScripter\Styles 
(%APPDATA% is the directory pointed by the corresponding environment variable). 
     
You can change  the active style by using the "View, Select Style" command. Your choice is then 
saved and used in future activations of PyScripter.
