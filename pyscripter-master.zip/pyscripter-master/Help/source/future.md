:::{index} PyScripter; Future
:::

# Future

Here is a list of the features planned for the not-too-distant future:  
- Python plugin architecture
- UML graphs generation
- GUI form designer  

You are welcome to [provide feedback](support) regarding the planned features. 


