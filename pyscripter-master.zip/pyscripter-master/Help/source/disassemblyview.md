:::{index} Editor Views; Disassembly
:::

# Disassembly View

PyScripter can use the standard Python module dis to disassemble Python Modules. This 
feature is available from the "Source Code Views" submenu of the [Tools menu](toolsmenu). 
The disassembly is displayed in a separate editor. To close the disassembly view, right-click on 
the "Disassembly" tab and select "Close".  
  
![graphic](images/disassemblyview1.JPG){align=center width="36.50em" height="22.31em"}
