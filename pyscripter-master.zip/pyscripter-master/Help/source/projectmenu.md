:::{index} Main Menu; Project
:::

# The Project Menu

![graphic](images/projectmenu1.png){width="13.84em"  height="10.31em"}

***Commands/Actions:***

*New Project*\
Clear the active project and start a new one.

*Open Project...*\
Open a saved project and replace the active one.

*Recent Projects*\
Shows you the list of most recent projects that you worked.

*Save Project*\
Save the active project.

*Save Project As...*\
Save the active project under a different name.

*Project Explorer*\
Show the [Project Explorer](projectexplorer) IDE window.
  



