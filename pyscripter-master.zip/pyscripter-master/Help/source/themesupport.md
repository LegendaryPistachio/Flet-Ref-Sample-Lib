:::{index} IDE; Styles
:::

# IDE Styles

The look-and-feel  of the IDE can be customized in different ways. The color scheme in particular
can be changed to one of many provided styles.

You can change the active style by using the "**View > Styles**" option which opens up a 
"Select Style" window as shown below. We're currently providing 27 styles to choose from them.
As you apply a style, your choice is then saved  and used in future activations of PyScripter.

![graphic](images/themesupport1.png){width="46.65em"  height="33.0em"}



