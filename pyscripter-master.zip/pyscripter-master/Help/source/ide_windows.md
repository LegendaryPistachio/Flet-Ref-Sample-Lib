:::{index} IDE Windows
:::


# IDE Windows

:::{toctree}
interpreter
codeexplorer
fileexplorer
projectexplorer
outputwindow
unittestwindow
todolistwindow
findinfileswindow
:::
