:::{index} Main Menu
:::


# Main Menu

:::{toctree}
filemenu
editmenu
searchmenu
viewmenu
projectmenu
runmenu
toolsmenu
helpmenu
:::
