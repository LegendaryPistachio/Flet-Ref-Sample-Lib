:::{index} PyScripter; Known Issues
:::

# Known Issues

**PyPy**

PyPy is not supported. You can use PyScripter with any standard
python distribution.  

