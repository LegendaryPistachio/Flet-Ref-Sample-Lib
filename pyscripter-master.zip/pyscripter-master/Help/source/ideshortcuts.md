:::{index} Customization; IDE Shortcuts
:::

# IDE Shortcuts

You can customize the IDE keyboard shortcuts using the "IDE Shortcuts..." command of the 
Options submenu of the [Tools menu](toolsmenu). In the dialog box shown below you 
can add or remove shortcuts for the the various commands. Note that you can have multiple shortcuts for each command.  
  
![graphic](images/ideshortcuts1.JPG){align=center width="22em" height="25.13em"}
