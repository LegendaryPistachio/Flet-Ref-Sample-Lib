:::{index} Customization
:::

# Customization

:::{toctree}
persistentoptions
ideoptions
ideshortcuts
editoroptions
importexportsettings
commandlineoptions
startup-python-scripts
filetemplates
toolbarcustomization
localization
customizablethemes
:::
