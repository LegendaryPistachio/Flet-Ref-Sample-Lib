# 本地以图搜图软件xiSearch-flet

## 简介

使用 sentence_transformers + flet 实现

项目地址：https://github.com/xjhqre/xiSearch-flet

## 使用说明

1、启动程序，进入设置页面，设置特征文件保存地址

![image-20230811145610238](README.assets/image-20230811145610238.png)

2、进入特征提取页面，输入要提取的图片库地址，点击特征提取按钮

![image-20230811165229261](README.assets/image-20230811165229261.png)

3、进入图片搜索页面搜索图片，点击图片即可复制文件路径

![image-20230811150235958](README.assets/image-20230811150235958.png)