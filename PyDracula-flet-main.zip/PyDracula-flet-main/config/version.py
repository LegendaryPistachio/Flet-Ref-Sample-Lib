VERSION = "0.1.8"
APP_DESCRIPTION = """
PyDracula-flet 是一个基于 Flet 参考 PyDracula 构建的现代化桌面应用程序框架。
它提供了：
• 深色/浅色主题支持
• 响应式布局
• 可配置的导航栏
• 配置持久化
"""

GITHUB_URL = "https://github.com/clarencejh/PyDracula-flet" 