import pathlib


CWD = pathlib.Path.cwd()
