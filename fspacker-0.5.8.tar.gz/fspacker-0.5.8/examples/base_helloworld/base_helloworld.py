from modules.module_a import function_a  # import from
from modules.module_b import function_b  # import from
import module_c  # import


def main():
    print("hello, world")

    function_a()
    function_b()
    module_c.function_c()
