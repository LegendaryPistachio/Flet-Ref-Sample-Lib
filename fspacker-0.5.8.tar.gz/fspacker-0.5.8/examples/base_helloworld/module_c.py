def function_c():
    print("Called from module_c, single file")
