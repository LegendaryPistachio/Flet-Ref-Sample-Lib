def function_a():
    print("Called from module_a, in folder")
