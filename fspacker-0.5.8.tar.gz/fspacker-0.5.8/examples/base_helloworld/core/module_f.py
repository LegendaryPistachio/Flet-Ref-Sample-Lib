import lxml


def function_f():
    print("Called from core.module_f, in folder")
    print(lxml.__version__)
