# load gz lib
import orderedset


def function_e():
    print("Called from core.module_e, in folder")
    print(f"loaded orderedset, version: {orderedset.__version__}")
