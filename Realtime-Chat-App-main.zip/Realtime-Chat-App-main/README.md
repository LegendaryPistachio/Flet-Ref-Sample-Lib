# Realtime-Chat-App
Realtime chat app in Python

### Install All Packages from a requirements.txt File Using pip and Python:

<code>pip install -r requirements.txt</code>

#### Run app:
<code>python main.py</code>

#### Sign in users default:
<code>User Name: mario Password: mario1</code>
####
<code>User Name: peach Password: peach1</code>


#### ScreenShots:
![home](Screenshots/home.png)
![signup](Screenshots/signup.png)
![chat](Screenshots/chat.png)

