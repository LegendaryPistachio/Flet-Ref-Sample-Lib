import subprocess

subprocess.run(["python", "-u", "-c", "lst=[]; lst.append(1)"])
