print(__name__)
