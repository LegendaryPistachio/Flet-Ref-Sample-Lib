This folder is copied from https://github.com/fabioz/PyDev.Debugger

Some print code in add_code_to_python_process.py is removed

The code and the binary in this folder is under EPL 1.0