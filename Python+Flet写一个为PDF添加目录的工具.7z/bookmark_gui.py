# coding:utf-8
import flet as ft
from PyPDF2 import PdfReader, PdfWriter
import os


class BookmarkLogic:
    def __init__(self):
        self.file_path = None
        self.file_name = None
        self.wasted_string = "…· ……"

    def set_file_info(self, files):
        if files:
            self.file_path = files[0].path
            self.file_name = files[0].name
        else:
            self.file_path = None
            self.file_name = None

    def get_selected_files_text(self):
        return self.file_name if self.file_name else "已取消！"

    def get_output_file_name(self):
        return f"{self.file_name.split('.')[0]}[带书签].pdf" if self.file_name else ""

    def clean_line(self, line: str):
        for i in self.wasted_string:
            line = line.replace(i, "")
        return line

    def parse_bookmarks(self, mulu_text):
        bookmarks = []
        current_level = 0
        level_indents = {0: 0}

        for line in mulu_text.splitlines():
            if not line.strip():
                continue

            indent = len(line) - len(line.lstrip())
            content = line.strip()

            if indent > level_indents[current_level]:
                current_level += 1
                level_indents[current_level] = indent
            elif indent < level_indents[current_level]:
                while current_level > 0 and indent < level_indents[current_level]:
                    current_level -= 1

            parts = content.rsplit(None, 1)
            if len(parts) == 2 and parts[1].isdigit():
                title, page = parts
                page = int(page)
            else:
                title, page = content, None

            bookmarks.append((title, page, current_level))

        return bookmarks

    def add_bookmarks_to_pdf(self, bookmarks, output_name, shift_value):
        output_path = os.path.join(os.path.dirname(self.file_path), output_name)

        pdf_in = PdfReader(self.file_path)
        pdf_out = PdfWriter()

        for page in pdf_in.pages:
            pdf_out.add_page(page)

        bookmark_objs = [None] * len(bookmarks)
        for i, (title, page, level) in enumerate(bookmarks):
            if page is not None:
                page = page + shift_value - 1
            parent = next(
                (
                    bookmark_objs[j]
                    for j in range(i - 1, -1, -1)
                    if bookmarks[j][2] < level
                ),
                None,
            )
            bookmark_objs[i] = pdf_out.add_outline_item(title, page, parent=parent)

        try:
            with open(output_path, "wb") as f:
                pdf_out.write(f)
            return True
        except Exception as e:
            print(f"写入PDF时发生错误: {e}")
            return False


class BookmarkGUI:
    def __init__(self):
        self.logic = BookmarkLogic()
        self.setup_controls()

    def setup_controls(self):
        # 初始化所有GUI控件
        self.mulu = ft.TextField(label="粘贴目录", multiline=True, min_lines=1, max_lines=300)
        self.shift = ft.TextField(value="0", label="页码偏移")
        self.output_name = ft.TextField(label="输出文件名")
        self.selected_files = ft.Text()
        self.pick_files_dialog = ft.FilePicker(on_result=self.pick_files_result)
        self.snack_bar = ft.SnackBar(
            bgcolor=ft.Colors.GREEN,  # 修改这里
            content=ft.Text("书签添加成功！"),
            action="好的！",
        )

    def main(self, page: ft.Page):
        self.page = page
        # 设置页面属性
        page.title = "添加书签"
        page.padding = 20
        page.window.left = 10
        page.window.top = 10
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.overlay.extend([self.snack_bar, self.pick_files_dialog])

        # 创建左侧面板
        left_panel = ft.Container(
            bgcolor=ft.Colors.BLUE_GREY_100,  # 修改这里
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.START,
                height=800,
                width=250,
                controls=[
                    ft.ElevatedButton(
                        "选择PDF文件",
                        icon=ft.Icons.UPLOAD_FILE,  # 修改这里
                        on_click=lambda _: self.pick_files_dialog.pick_files(allow_multiple=True),
                    ),
                    self.selected_files,
                    self.shift,
                    self.output_name,
                    ft.ElevatedButton("添加书签", on_click=self.add_mark),
                ],
            ),
        )

        # 创建右侧面板
        right_panel = ft.Container(height=800, width=800, content=self.mulu)

        # 添加页面内容
        page.add(ft.Row([left_panel, right_panel]))
        page.update()

    def pick_files_result(self, e: ft.FilePickerResultEvent):
        # 处理文件选择结果
        self.logic.set_file_info(e.files)
        self.selected_files.value = self.logic.get_selected_files_text()
        self.output_name.value = self.logic.get_output_file_name()
        self.output_name.update()
        self.selected_files.update()

    def add_mark(self, e):
        # 添加书签
        if not self.logic.file_path:
            return

        bookmarks = self.logic.parse_bookmarks(self.mulu.value)
        success = self.logic.add_bookmarks_to_pdf(
            bookmarks, self.output_name.value, int(self.shift.value)
        )

        if success:
            self.snack_bar.open = True
            self.page.update()


# 主程序部分保持不变
if __name__ == "__main__":
    app = BookmarkGUI()
    ft.app(target=app.main)