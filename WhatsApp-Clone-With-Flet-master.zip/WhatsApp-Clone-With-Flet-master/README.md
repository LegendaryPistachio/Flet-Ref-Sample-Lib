# WhatsApp-Clone-With-Flet


## Please do not sell this code :(
I cloned WhatsApp using only python flet. Feel free to clone this project and make it better. Let's take flet to another level. 


![ui](assets/ui.png)
