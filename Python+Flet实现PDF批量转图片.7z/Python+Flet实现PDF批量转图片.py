import flet as ft
import os
import fitz
from PIL import Image
import asyncio
import json

class PDFConverter:
    def __init__(self):
        self.output_path = None
        self.pdf_files = []
        self.config_file = "recent_folders.json"
        self.recent_folders = self.load_recent_folders()

    def load_recent_folders(self):
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                return json.load(f)
        return []

    def save_recent_folders(self):
        with open(self.config_file, 'w') as f:
            json.dump(self.recent_folders, f)

    def add_recent_folder(self, folder):
        if folder in self.recent_folders:
            self.recent_folders.remove(folder)
        self.recent_folders.insert(0, folder)
        self.recent_folders = self.recent_folders[:5]  # 只保留最近的5个文件夹
        self.save_recent_folders()

    async def convert_pdfs(self, progress_callback):
        total_pages = sum(len(fitz.open(pdf.path)) for pdf in self.pdf_files)
        processed_pages = 0
        
        for pdf in self.pdf_files:
            doc = fitz.open(pdf.path)
            for page_num in range(len(doc)):
                page_content = doc.load_page(page_num)
                pix = page_content.get_pixmap(matrix=fitz.Matrix(300/72, 300/72))  # 300 DPI
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                img_path = os.path.join(self.output_path, f"{os.path.splitext(pdf.name)[0]}_page_{page_num+1}.png")
                img.save(img_path, "PNG")
                
                processed_pages += 1
                await progress_callback(processed_pages, total_pages)
                await asyncio.sleep(0)  # 让出控制权,使UI能够更新
            
            doc.close()

class PDFGUI:
    def __init__(self):
        self.converter = PDFConverter()
        self.page = None
        self.output_path_text = None
        self.files_text = None
        self.progress = None
        self.progress_text = None
        self.convert_button = None
        self.recent_folders_dropdown = None
        self.pick_dir_dialog = None
        self.pick_pdf_dialog = None

    def create_ui(self):
        self.page.title = "PDF转PNG工具"
        self.page.padding = 50
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.bgcolor = ft.colors.BLUE_GREY_50

        self.output_path_text = ft.Text(size=14, color=ft.colors.BLUE_GREY_800)
        self.files_text = ft.Text("未选择PDF文件", size=14, color=ft.colors.BLUE_GREY_800)
        self.progress = ft.ProgressBar(width=400, visible=False, color=ft.colors.BLUE_600)
        self.progress_text = ft.Text("", visible=False, size=14, color=ft.colors.BLUE_GREY_800)

        self.pick_dir_dialog = ft.FilePicker(on_result=self.output_dir_result)
        self.pick_pdf_dialog = ft.FilePicker(on_result=self.pdf_picker_result)
        self.page.overlay.extend([self.pick_dir_dialog, self.pick_pdf_dialog])

        pick_dir_button = self.create_button("选择输出文件夹", lambda _: self.pick_dir_dialog.get_directory_path(), ft.colors.BLUE_600)
        pick_pdf_button = self.create_button("选择PDF文件", self.pick_pdf_files, ft.colors.GREEN_600)
        self.convert_button = self.create_button("转换图片", self.convert_pdfs, ft.colors.ORANGE_600)

        self.recent_folders_dropdown = ft.Dropdown(
            label="最近使用的文件夹",
            width=500,
            options=[ft.dropdown.Option("请选择文件夹")] + [ft.dropdown.Option(folder) for folder in self.converter.recent_folders],
            on_change=self.on_recent_folder_selected
        )

        content = ft.Column([
            ft.Text("PDF转PNG工具", size=30, weight=ft.FontWeight.BOLD, color=ft.colors.BLUE_GREY_900),
            ft.Divider(height=30, color=ft.colors.BLUE_GREY_200),
            ft.Text("步骤1: 选择输出文件夹", size=18, weight=ft.FontWeight.BOLD, color=ft.colors.BLUE_GREY_800),
            ft.Row([
                ft.Column([pick_dir_button], alignment=ft.MainAxisAlignment.START),
                ft.Column([self.recent_folders_dropdown], alignment=ft.MainAxisAlignment.END)
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            self.output_path_text,
            ft.Divider(height=30, color=ft.colors.BLUE_GREY_200),
            ft.Text("步骤2: 选择PDF文件", size=18, weight=ft.FontWeight.BOLD, color=ft.colors.BLUE_GREY_800),
            ft.Row([pick_pdf_button, self.files_text], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Divider(height=30, color=ft.colors.BLUE_GREY_200),
            ft.Text("步骤3: 转换图片", size=18, weight=ft.FontWeight.BOLD, color=ft.colors.BLUE_GREY_800),
            self.convert_button,
            self.progress,
            self.progress_text
        ], spacing=20)

        self.page.add(content)

    def create_button(self, text, on_click, bgcolor):
        return ft.ElevatedButton(
            text, 
            on_click=on_click,
            style=ft.ButtonStyle(
                color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                bgcolor={ft.MaterialState.DEFAULT: bgcolor},
                padding=10,
            ),
            width=150
        )

    def output_dir_result(self, e: ft.FilePickerResultEvent):
        if e.path:
            self.converter.output_path = e.path
            self.converter.add_recent_folder(e.path)
            self.output_path_text.value = f"选择的输出文件夹: {self.converter.output_path}"
            self.update_recent_folders_dropdown()
            self.recent_folders_dropdown.value = e.path  # 更新下拉菜单的选中值
        else:
            self.output_path_text.value = "未选择输出文件夹"
        self.page.update()

    def update_recent_folders_dropdown(self):
        self.recent_folders_dropdown.options = [ft.dropdown.Option("请选择文件夹")] + [ft.dropdown.Option(folder) for folder in self.converter.recent_folders]
        self.page.update()

    def on_recent_folder_selected(self, e):
        if e.control.value == "请选择文件夹":
            self.pick_dir_dialog.get_directory_path()
        else:
            self.converter.output_path = e.control.value
            self.output_path_text.value = f"选择的输出文件夹: {self.converter.output_path}"
            self.page.update()

    def pick_pdf_files(self, _):
        if self.converter.output_path:
            self.pick_pdf_dialog.initial_directory = self.converter.output_path
        self.pick_pdf_dialog.pick_files(allow_multiple=True, allowed_extensions=['pdf'])

    def pdf_picker_result(self, e: ft.FilePickerResultEvent):
        if e.files:
            self.converter.pdf_files = [f for f in e.files if f.name.lower().endswith('.pdf')]
            self.files_text.value = f"已选择 {len(self.converter.pdf_files)} 个PDF文件"
            self.page.update()

    async def convert_pdfs(self, _):
        if not self.converter.output_path or self.converter.output_path == "未选择输出文件夹":
            self.show_snackbar("请先选择输出文件夹")
            return
        
        if not self.converter.pdf_files:
            self.show_snackbar("请先选择PDF文件")
            return
        
        self.progress.visible = True
        self.progress_text.visible = True
        self.convert_button.disabled = True
        self.page.update()
        
        await self.converter.convert_pdfs(self.update_progress)
        
        self.progress.visible = False
        self.progress_text.visible = False
        self.convert_button.disabled = False
        self.show_snackbar("转换完成")

    async def update_progress(self, processed, total):
        self.progress.value = processed / total
        self.progress_text.value = f"进度: {processed}/{total} 页"
        await self.page.update_async()

    def show_snackbar(self, message):
        self.page.snack_bar = ft.SnackBar(content=ft.Text(message))
        self.page.snack_bar.open = True
        self.page.update()

async def main(page: ft.Page):
    gui = PDFGUI()
    gui.page = page
    gui.create_ui()

ft.app(target=main)