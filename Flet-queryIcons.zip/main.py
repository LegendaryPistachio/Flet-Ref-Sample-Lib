import flet as ft
from fletIcons import FLET_ICONS

# 分页模块，封装好分页逻辑，通过传入的 on_page_change 回调当前选中的页码和数据
class Pagination(ft.Row):
    def __init__(self, page, page_size=84, page_per_group=12, on_page_change=None):
        super().__init__()
        self.page = page
        self.page_size = page_size  # 每页显示的数据条数
        self.page_per_group = page_per_group  # 分页按钮每次显示数量
        self.data_list = []  # 数据列表
        self.total_pages = 0  # 总页数
        self.current_page = 1  # 当前页码
        self.on_page_change_callback = on_page_change  # 页码回调函数
        self.spacing = 1
        self.expand = 1
        self.wrap = True
        self.alignment = ft.MainAxisAlignment.CENTER
        self.controls = []  # 按钮控件列表
        self.page_group = []  # 当前显示的页码组

    # 获取当前页的数据
    def get_page_data(self, page_number):
        start_index = (page_number - 1) * self.page_size
        end_index = start_index + self.page_size
        return self.data_list[start_index:end_index]

    # 更新页码按钮显示的范围
    def update_page_group(self):
        start = max(self.current_page - (self.page_per_group // 2), 1)
        end = min(start + self.page_per_group, self.total_pages + 1)
        self.page_group = list(range(start, end))

    # 选择特定页码，更新显示数据
    def select_page(self, page):
        if 1 <= page <= self.total_pages:
            self.current_page = page
            self.update_page_group()  # 更新当前页码组
            list_icons = self.get_page_data(page)
            if self.on_page_change_callback:
                self.on_page_change_callback(page, list_icons)  # 回调页码和数据
        else:
            print("页码超出范围")

    # 初始化数据查询
    def query_start(self, data_list):
        self.current_page = 1
        self.data_list = data_list  # 设置数据
        self.total_pages = self.get_total_pages()  # 计算总页数
        self.update_page_group()
        self.select_page(self.current_page)
        self.update_btns()

    # 更新分页按钮
    def update_btns(self):
        self.controls = []

        # 上一页按钮
        btn_up = ft.OutlinedButton(
            text="<",
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)),
            disabled=self.current_page == 1,  # 如果是第一页，禁用按钮
            data=self.current_page,
            on_click=self.select_up,
        )
        self.controls.append(btn_up)

        # 中间页码按钮
        for p in self.page_group:
            selected_index = (p == self.current_page)  # 当前页按钮禁用
            btns = ft.OutlinedButton(
                text=str(p),
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)),
                disabled=selected_index,
                data=p,
                on_click=self.select_btns,
            )
            self.controls.append(btns)

        # 下一页按钮
        btn_down = ft.OutlinedButton(
            text=">",
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)),
            disabled=self.current_page >= self.total_pages,  # 如果是最后一页，禁用按钮
            data=self.current_page,
            on_click=self.select_down,
        )
        self.controls.append(btn_down)
        self.page.update()

    # 页码按钮点击事件
    def select_btns(self, e):
        new_page = e.control.data
        self.select_page(new_page)
        self.update_btns()

    # 上一页点击事件
    def select_up(self, e):
        if self.current_page > 1:
            self.select_page(self.current_page - 1)
            self.update_btns()

    # 下一页点击事件
    def select_down(self, e):
        if self.current_page < self.total_pages:
            self.select_page(self.current_page + 1)
            self.update_btns()

    # 计算总页数
    def get_total_pages(self):
        total_items = len(self.data_list)
        total_pages = total_items // self.page_size
        if total_items % self.page_size != 0:
            total_pages += 1
        return total_pages


# 生成图标展示列表
class IconsRow(ft.ResponsiveRow):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.Message_class = Message(self.page)  # 消息提示组件
        self.controls = []

    # 更新图标展示数据
    def update_data(self, list_icons):
        self.controls = []
        for item in list_icons:
            self.controls.append(
                ft.Card(
                    ft.Container(
                        content=ft.Column(
                            controls=[
                                ft.Row(controls=[ft.Icon(name=item, color=ft.colors.BLACK)], alignment=ft.MainAxisAlignment.CENTER),
                                ft.Text(item, max_lines=1, overflow="ellipsis", size=12),
                            ],
                        ),
                        padding=5,
                        data=item,
                        border_radius=ft.border_radius.all(5),
                        on_click=self.copy_current_page,
                        ink=True,
                        ink_color="blue",
                    ),
                    col={"md": 1},
                    tooltip=ft.Tooltip(message=item),
                )
            )
        self.page.update()

    # 复制当前图标名称
    def copy_current_page(self, e):
        self.Message_class.show(f"已复制：{e.control.data} 到剪切板")
        self.page.set_clipboard(e.control.data)


# 消息提示层
class Message(ft.SnackBar):
    def __init__(self, page: ft.Page):
        self.page = page
        self.snack_bar = None

    # 显示消息提示
    def show(self, message: str):
        if self.snack_bar is not None:
            self.page.overlay.remove(self.snack_bar)  # 移除旧的SnackBar

        # 创建新的SnackBar
        self.snack_bar = ft.SnackBar(
            ft.Text(message),
        )
        
        self.page.overlay.append(self.snack_bar)
        self.snack_bar.open = True
        self.page.update()

    # 隐藏消息提示
    def hide(self):
        if self.snack_bar is not None:
            self.snack_bar.open = False
            self.page.update()
            self.page.overlay.remove(self.snack_bar)
            self.snack_bar = None


# 主视图
class MainView(ft.Container):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.pager = Pagination(self.page, on_page_change=self.on_page_change)
        self.icon_rows = IconsRow(self.page)
        self.query_name = ft.TextField(hint_text="输入要查询的图标", text_size=12, on_change=self.queryIcons)
        self.expand = 1
        self.padding = 1

        # 布局
        self.content = ft.Column(
            scroll=ft.ScrollMode.AUTO,
            spacing=1,
            expand=1,
            controls=[
                # 搜索行
                ft.Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    controls=[self.query_name],
                ),
                # 内容行
                ft.Row(
                    controls=[
                        ft.Container(
                            expand=1,
                            content=self.icon_rows,
                        ),
                    ]
                ),
                ft.Divider(height=5),
                # 翻页行按钮
                ft.Row([self.pager]),
            ]
        )

        # 初始化数据
        ret = self.paginate_list('')
        if ret:
            self.pager.query_start(ret)

    # 查询图标
    def queryIcons(self, e):
        query = self.query_name.value.upper()
        ret = self.paginate_list(query)
        if ret:
            self.pager.query_start(ret)

    # 页面变化时更新数据
    def on_page_change(self, page_number, list_icons):
        self.icon_rows.update_data(list_icons)

    # 根据查询返回分页图标列表
    def paginate_list(self, query):
        return [name for name in FLET_ICONS if query in name]


# 运行应用程序
def main(page: ft.Page):
    page.title = "Flet图标查询器 -- By 吖嗪"
    page.padding = 2
    mv = MainView(page)
    page.add(mv)


ft.app(target=main)
