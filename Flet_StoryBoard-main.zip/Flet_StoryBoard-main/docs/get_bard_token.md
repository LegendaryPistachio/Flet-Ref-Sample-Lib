# How to get bard API token ?
To get your bard API token, open google bard page: (Google bard)[https://bard.google.com/], then open the inspector.

<img width="700" alt="Screenshot 2023-05-28 at 7 37 35 PM" src="https://github.com/SKbarbon/Flet_StoryBoard/assets/86029286/72934c7e-060d-4d72-b88e-22a960002224">

Then open the "Application" page, then find the `https://bard.google.com` section that under the cookies. Then search for `__Secure-1PSID` then copy its value.

<img width="1728" alt="Screenshot 2023-05-28 at 7 38 03 PM" src="https://github.com/SKbarbon/Flet_StoryBoard/assets/86029286/d22f7653-844c-4b8f-bd46-e1db24f04cf5">

## Dont share it with any one!
