print("""
These are all 'Flet_StoryBoard' commands:

.edit: For create/edit an exist storyboard => python3 -m Flet_StoryBoard.edit <yourfilename.fletsb>

""")