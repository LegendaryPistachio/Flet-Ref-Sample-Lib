import flet as ft

def main(page: ft.Page):
    page.title = "Cursor Pricing-python和flet生成这个截图GUI-作者：知乎@丑人多作怪"
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 0
    
    def create_nav_item(text):
        return ft.TextButton(text, style=ft.ButtonStyle(color=ft.colors.WHITE))

    nav_bar = ft.AppBar(
        leading=ft.Icon(ft.icons.ABC),
        leading_width=40,
        title=ft.Text("CURSOR"),
        center_title=False,
        bgcolor=ft.colors.BLACK,
        actions=[
            create_nav_item("Pricing"),
            create_nav_item("Features"),
            create_nav_item("Forum"),
            create_nav_item("Docs"),
            create_nav_item("Careers"),
            create_nav_item("Blog"),
            ft.TextButton("Settings"),
            ft.TextButton("Logout"),
            ft.ElevatedButton("Download", bgcolor=ft.colors.BLUE)
        ],
    )

    header = ft.Container(
        content=ft.Column([
            ft.Text("Pricing", size=60, weight=ft.FontWeight.BOLD),
            ft.Text("Choose the plan that works for you", size=20),
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        gradient=ft.LinearGradient(
            begin=ft.alignment.top_left,
            end=ft.alignment.bottom_right,
            colors=[ft.colors.PURPLE, ft.colors.BLUE, ft.colors.GREEN, ft.colors.YELLOW]
        ),
        height=300,
        alignment=ft.alignment.center,
    )

    toggle = ft.Row([
        ft.ElevatedButton("Monthly", bgcolor=ft.colors.BLUE),
        ft.OutlinedButton("Yearly (Save $48)")
    ], alignment=ft.MainAxisAlignment.CENTER)

    def create_plan_card(title, price, features, button_text):
        return ft.Card(
            content=ft.Container(
                content=ft.Column([
                    ft.Text(title, weight=ft.FontWeight.BOLD),
                    ft.Text(price, size=30, weight=ft.FontWeight.BOLD),
                    ft.Text("Includes"),
                    *[ft.Text(f"✓ {feature}", size=14) for feature in features],
                    ft.ElevatedButton(button_text, bgcolor=ft.colors.BLUE if title == "Pro" else None)
                ], spacing=20),
                padding=20,
            ),
            width=300,
        )

    plans = ft.Row([
        create_plan_card("Hobby", "Free", 
                         ["Pro two-week trial", "2000 completions", "50 slow premium requests", "200 cursor-small uses"],
                         "Download for Windows"),
        create_plan_card("Pro", "$20 / Month", 
                         ["Unlimited completions", "500 fast premium requests® per month", "Unlimited slow premium requests", "Unlimited cursor-small uses", "10 Claude Opus uses per day"],
                         "Get started"),
        create_plan_card("Business", "$40 / User / Month", 
                         ["Centralized billing", "Admin usage dashboard", "Enforce privacy mode", "OpenAI/Anthropic zero-data retention"],
                         "Get started"),
    ], alignment=ft.MainAxisAlignment.CENTER)

    faq = ft.Column([
        ft.Text("Frequently Asked Questions", size=30, weight=ft.FontWeight.BOLD),
        ft.Row([
            ft.Column([
                ft.Text("Why isn't Cursor completely free?", weight=ft.FontWeight.BOLD),
                ft.Text("Large-language models cost quite a bit of money to run. To grow Cursor sustainably without compromising our service quality, we need to cover our costs.", width=400)
            ]),
            ft.Column([
                ft.Text("What are the premium models?", weight=ft.FontWeight.BOLD),
                ft.Text("GPT-4, GPT-4o, and Claude 3.5 Sonnet are all considered premium models. You have 500 fast uses and unlimited slow uses each month for these models.", width=400)
            ])
        ], alignment=ft.MainAxisAlignment.CENTER)
    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    page.add(
        nav_bar,
        header,
        toggle,
        plans,
        faq
    )

ft.app(target=main)