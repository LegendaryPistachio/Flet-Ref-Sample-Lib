# Typing Animation

A row containing animated bubbles.

**Use-case:** Could be used for typing animations in chat apps.

I somehow followed this Flutter guide to build it up.

Running the examples I made, you will have the following results:

### Example 1:
![typing-animation-avatar-gif](https://user-images.githubusercontent.com/98978078/218187311-b2b75d23-bcb1-488a-8eb8-b5622d4aa034.gif)

### Example 2:
Tried to mimic this flutter example: https://docs.flutter.dev/cookbook/effects/typing-indicator
![typing-animation gif](https://user-images.githubusercontent.com/98978078/218187426-6e3aaefa-2335-4dcd-8477-05d8b9e8b3aa.gif)


If you have any problems or questions, feel free to [open an issue](https://github.com/ndonkoHenri/Flet-Custom-Controls/issues).
