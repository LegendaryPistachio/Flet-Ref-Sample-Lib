# Flet Custom Controls
 A collection of custom controls I made for use by flet devs. 

- Paginated DataTable
- Typing Animation
- Vertical Slider
- SizeAwareControl - [Article](https://ndonkohenri.medium.com/how-to-determine-the-size-of-any-flet-control-python-ddc5631dd442)
