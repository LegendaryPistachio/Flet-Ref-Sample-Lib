# Forms

Login and Registration Forms. Could be customized for re-use.
 
## Content (WIP)
- [x] Login Form with Captcha;
- [ ] Registration Form with Captcha;
- [ ] App with login and registration views connected to an external service (firebase, supabase ...)

## Captures
- Login Form with Captcha:

https://github.com/ndonkoHenri/Flet-Samples/assets/98978078/d568daa3-e73c-41c1-9cf1-a1861a5ee6f6



