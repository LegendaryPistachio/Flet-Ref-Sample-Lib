# Flet URL shortener

Using long URLs is sometimes annoying, boring and tedious. 
This tool is here to help shorten these URLs, making them more beautiful to see, and also easy to memorize.

## Captures

https://user-images.githubusercontent.com/98978078/197305959-6dfad1c8-e6d8-4b71-9137-4975bbbc49f5.mp4


